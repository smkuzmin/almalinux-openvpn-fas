@echo off
set PATH=%SYSTEMROOT%\SYSTEM32;%SYSTEMROOT%;%SYSTEMROOT%\SYSTEM32\WBEM;
chcp.com>nul 866

:: https://build.openvpn.net/downloads/releases/openvpn-install-2.4.11-I602-Win10.exe
:: https://build.openvpn.net/downloads/releases/openvpn-install-2.3.18-I001-i686.exe

set PROGRAM_DIR=%ProgramFiles: (x86)=%
set PROGRAM_DESC=VPN-������
set PROGRAM_NAME=OpenVPN
set PROGRAM_EXEC=openvpn-run.vbs
set PROGRAM_ICON=openvpn.ico

set OS_VER=Win7-11
ver.exe 2>nul|find.exe>nul 2>nul " 5." && set OS_VER=WinXP
set OS_ARC=x32
if defined ProgramFiles(x86) set OS_ARC=x64
:: WinRAR defaults to a 32-bit SFX module for creating self-extracting archives.
:: On 64-bit systems, 32-bit applications (including SFX installers) are redirected to WOW6432Node,
:: which may affect registry operations (e.g., writing to 64-bit registry keys).
:: "Sysnative" is a virtual path that works only for 32-bit apps on 64-bit systems,
:: allowing access to 64-bit resources (like reg.exe) by bypassing WOW64 redirection.
:: Detect 32-bit processes on 64-bit systems to use Sysnative for 64-bit registry access:
set REG=reg.exe
if "%PROCESSOR_ARCHITECTURE%%OS_ARC%"=="x86x64" set REG=%SYSTEMROOT%\Sysnative\reg.exe

set KEY=%~1
if defined SFXCMD set SFXCMD=%SFXCMD:*.exe=%
if defined SFXCMD set SFXCMD=%SFXCMD:"=%
if defined SFXCMD set    KEY=%SFXCMD: =%
if defined KEY    set    KEY=%KEY:/=-%

if /I "%KEY%"=="-sfx" goto MakeSFX

:UnInstall
taskkill.exe>nul 2>nul /F /T /IM "openvpn*" /IM "openssl.exe" /IM "autoit3.exe" /IM "devcon32.exe" /IM "devcon64.exe" /IM "tap-windows.exe"
"%PROGRAM_DIR%\%PROGRAM_NAME%\uninstall.exe">nul 2>nul /S
call        >nul 2>nul "%~dp0Files\bin\tapdel.bat"
sc.exe      >nul 2>nul delete "OpenVPNServiceInteractive"
sc.exe      >nul 2>nul delete "OpenVPNServiceLegacy"
sc.exe      >nul 2>nul delete "OpenVPNService"
%REG%       >nul 2>nul delete "HKLM\SYSTEM\CurrentControlSet\services\OpenVPNServiceInteractive" /F
%REG%       >nul 2>nul delete "HKLM\SYSTEM\ControlSet001\services\OpenVPNServiceInteractive" /F
%REG%       >nul 2>nul delete "HKLM\SYSTEM\ControlSet002\services\OpenVPNServiceInteractive" /F
%REG%       >nul 2>nul delete "HKLM\SYSTEM\CurrentControlSet\services\OpenVPNServiceLegacy" /F
%REG%       >nul 2>nul delete "HKLM\SYSTEM\ControlSet001\services\OpenVPNServiceLegacy" /F
%REG%       >nul 2>nul delete "HKLM\SYSTEM\ControlSet002\services\OpenVPNServiceLegacy" /F
%REG%       >nul 2>nul delete "HKLM\SYSTEM\CurrentControlSet\services\OpenVPNService" /F
%REG%       >nul 2>nul delete "HKLM\SYSTEM\ControlSet001\services\OpenVPNService" /F
%REG%       >nul 2>nul delete "HKLM\SYSTEM\ControlSet002\services\OpenVPNService" /F
%REG%       >nul 2>nul delete "HKLM\SOFTWARE\OpenVPN" /F
%REG%       >nul 2>nul delete "HKLM\SOFTWARE\OpenVPN-GUI" /F
%REG%       >nul 2>nul delete "HKLM\SOFTWARE\Wow6432Node\OpenVPN" /F
%REG%       >nul 2>nul delete "HKLM\SOFTWARE\Wow6432Node\OpenVPN-GUI" /F
%REG%       >nul 2>nul delete "HKCR\.ovpn" /F
%REG%       >nul 2>nul delete "HKCR\OpenVPN" /F
%REG%       >nul 2>nul delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.ovpn" /F
call        >nul 2>nul :DelDirInProgs "OpenVPN"
call        >nul 2>nul :DelDirInUsers "OpenVPN"
call        >nul 2>nul :DelShortcuts  "OpenVPN"
call        >nul 2>nul :DelShortcuts  "OpenVPN GUI"
call        >nul 2>nul :DelShortcuts  "TAP-Windows"
if /I "%KEY%"=="-u" goto Finish

:Install
call        >nul 2>nul "%~dp0Files\bin\tapadd.bat" || goto Finish
call        >nul 2>nul "%~dp0Files\bin\taphide.bat"
call        >nul 2>nul "%~dp0Files\bin\tapsetmetric.bat"
xcopy.exe   >nul 2>nul /C /H /I /R /E /Y /Z "%~dp0Files"                  "%PROGRAM_DIR%\%PROGRAM_NAME%\"
xcopy.exe   >nul 2>nul /C /H /I /R /E /Y /Z "%~dp0Files.%OS_VER%%OS_ARC%" "%PROGRAM_DIR%\%PROGRAM_NAME%\"
%REG%       >nul 2>nul add "HKLM\SOFTWARE\OpenVPN"           /VE             /T REG_SZ /D "%PROGRAM_DIR%\%PROGRAM_NAME%" /F
%REG%       >nul 2>nul add "HKLM\SOFTWARE\OpenVPN"           /V "config_dir" /T REG_SZ /D "%PROGRAM_DIR%\%PROGRAM_NAME%\config" /F
%REG%       >nul 2>nul add "HKLM\SOFTWARE\OpenVPN"           /V "config_ext" /T REG_SZ /D "ovpn" /F
%REG%       >nul 2>nul add "HKLM\SOFTWARE\OpenVPN"           /V "exe_path"   /T REG_SZ /D "%PROGRAM_DIR%\%PROGRAM_NAME%\bin\openvpn.exe" /F
%REG%       >nul 2>nul add "HKLM\SOFTWARE\OpenVPN"           /V "log_dir"    /T REG_SZ /D "%PROGRAM_DIR%\%PROGRAM_NAME%\log" /F
%REG%       >nul 2>nul add "HKLM\SOFTWARE\OpenVPN"           /V "priority"   /T REG_SZ /D "NORMAL_PRIORITY_CLASS" /F
%REG%       >nul 2>nul add "HKLM\SOFTWARE\OpenVPN"           /V "log_append" /T REG_SZ /D "0" /F
%REG%       >nul 2>nul add "HKCR\.ovpn"                      /VE             /T REG_SZ /D "OpenVPN" /F
%REG%       >nul 2>nul add "HKCR\OpenVPN"                    /VE             /T REG_SZ /D "OpenVPN configuration file" /F
%REG%       >nul 2>nul add "HKCR\OpenVPN\DefaultIcon"        /VE             /T REG_SZ /D "%PROGRAM_DIR%\%PROGRAM_NAME%\openvpn.ico" /F
%REG%       >nul 2>nul add "HKCR\OpenVPN\shell"              /VE             /T REG_SZ /D "" /F
%REG%       >nul 2>nul add "HKCR\OpenVPN\shell\open"         /VE             /T REG_SZ /D "" /F
%REG%       >nul 2>nul add "HKCR\OpenVPN\shell\open\command" /VE             /T REG_SZ /D "notepad.exe \"%%1\"" /F
%REG%       >nul 2>nul add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.ovpn\UserChoice" /V "Progid" /T REG_SZ /D "OpenVPN" /F
sc.exe      >nul 2>nul create "OpenVPNServiceInteractive" binPath= "\"%PROGRAM_DIR%\%PROGRAM_NAME%\bin\openvpnserv.exe\"" DisplayName= "OpenVPN Interactive Service" start= "auto" type= "share"
sc.exe      >nul 2>nul start  "OpenVPNServiceInteractive"
wscript.exe >nul 2>nul "%~dp0shortcut.vbs" "%PROGRAM_DIR%\%PROGRAM_NAME%\bin\%PROGRAM_EXEC%" "AllUsersPrograms" "%PROGRAM_NAME%" "%PROGRAM_DESC%" "%PROGRAM_DIR%\%PROGRAM_NAME%\%PROGRAM_ICON%"
wscript.exe >nul 2>nul "%~dp0shortcut.vbs" "%PROGRAM_DIR%\%PROGRAM_NAME%\bin\%PROGRAM_EXEC%" "AllUsersDesktop"  "%PROGRAM_NAME%" "%PROGRAM_DESC%" "%PROGRAM_DIR%\%PROGRAM_NAME%\%PROGRAM_ICON%"
goto Finish

:MakeSFX
setlocal
cd /D "%~dp0"
del>nul 2>nul /A /F /Q "..\%PROGRAM_NAME%.exe"
echo> "%TEMP%\makesfx.cfg" Path=%%TEMP%%\%PROGRAM_NAME%
echo>>"%TEMP%\makesfx.cfg" Overwrite=1
echo>>"%TEMP%\makesfx.cfg" Silent=1
echo>>"%TEMP%\makesfx.cfg" Setup=Files\hidec.exe "%%COMSPEC%%" /C "install.bat %%~1 & ping.exe 127.0.0.1 -n 11 & cd .. && rmdir /S /Q "%%TEMP%%\%PROGRAM_NAME%""
if defined PROGRAM_ICON set PROGRAM_ICON=-iicon"Files\%PROGRAM_ICON%"
start /wait winrar a %PROGRAM_ICON% -z"%TEMP%\makesfx.cfg" -cfg- -ep1 -dh -s -r -m5 -sfx -kb -t "..\%PROGRAM_NAME%.exe" *
del>nul 2>nul /A /F /Q "%TEMP%\makesfx.cfg"
endlocal
goto Finish

:ExistFile
if "%~1"=="" exit /B 255
dir>nul 2>nul /A:-D "%~1" || exit /B 1
exit /B 0

:ExistDir
if "%~1"=="" exit /B 255
dir>nul 2>nul /A:D "%~1" || exit /B 1
exit /B 0

:DelFile
call>nul 2>nul :ExistFile "%~1" || exit /B
setlocal
cd /D "%~dp1"
set myname=%~1
:DelFile_Loop
if not defined myname exit /B
if "%myname%"=="%myname:*\=%" goto DelFile_Skip
set myname=%myname:*\=%
goto DelFile_Loop
:DelFile_Skip
forfiles.exe 2>nul /C "%COMSPEC% /C if @isdir==FALSE ( del /A /F /Q @path )" /M "%myname%" || del /A /F /Q "%~1"
endlocal
exit /B

:DelDir
call>nul 2>nul :ExistDir "%~1" || exit /B
setlocal
cd /D "%~dp1"
set myname=%~1
:DelDir_Loop
if not defined myname exit /B
if "%myname%"=="%myname:*\=%" goto DelDir_Skip
set myname=%myname:*\=%
goto DelDir_Loop
:DelDir_Skip
forfiles.exe 2>nul /C "%COMSPEC% /C if @isdir==TRUE ( rmdir /S /Q @path )" /M "%myname%" || rmdir /S /Q "%~1"
endlocal
exit /B

:DelDirInProgs
if "%~1"=="" exit /B 1
if defined ProgramFiles      call :DelDir "%ProgramFiles: (x86)=%\%~1"
if defined ProgramFiles(x86) call :DelDir "%ProgramFiles(x86)%\%~1"
for /D %%i in ("%SYSTEMDRIVE%\Users" "%SYSTEMDRIVE%\Documents and Settings") do ^
for /D %%j in ("%%~i\All Users" "%%~i\Default" "%%~i\Public" "%%~i\�����������" "%%~i\*.*") do (
  for /D %%k in ("%%~j\AppData\Local\VirtualStore\Program Files\%~1"      ) do call :DelDir "%%~k"
  for /D %%k in ("%%~j\AppData\Local\VirtualStore\Program Files (x86)\%~1") do call :DelDir "%%~k"
)
exit /B

:DelShortcuts
if "%~1"=="" exit /B 1
for /D %%i in ("%SYSTEMDRIVE%\Users" "D:\Users" "%SYSTEMDRIVE%\Documents and Settings") do ^
for /D %%j in ("%%~i\*.*" "%%~i\All Users" "%%~i\Default" "%%~i\�� ���짮��⥫�") do (
  call :DelDir  "%%~j\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\%~1"
  call :DelDir  "%%~j\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\%~1"
  call :DelDir  "%%~j\AppData\Roaming\Microsoft\Windows\Start Menu\%~1"
  call :DelDir  "%%~j\Microsoft\Windows\Start Menu\Programs\Startup\%~1"
  call :DelDir  "%%~j\Microsoft\Windows\Start Menu\Programs\%~1"
  call :DelDir  "%%~j\Microsoft\Windows\Start Menu\%~1"
  call :DelDir  "%%~j\������� ����\�ணࠬ��\��⮧���㧪�\%~1"
  call :DelDir  "%%~j\������� ����\�ணࠬ��\%~1"
  call :DelDir  "%%~j\������� ����\%~1"
  call :DelFile "%%~j\AppData\Roaming\ClassicShell\Pinned\%~1.lnk"
  call :DelFile "%%~j\AppData\Roaming\Microsoft\Internet Explorer\Quick Launch\User Pinned\StartMenu\%~1.lnk"
::call :DelFile "%%~j\AppData\Roaming\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar\%~1.lnk"
  call :DelFile "%%~j\AppData\Roaming\Microsoft\Internet Explorer\Quick Launch\%~1.lnk"
  call :DelFile "%%~j\AppData\Roaming\Microsoft\Windows\SendTo\%~1.lnk"
  call :DelFile "%%~j\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\%~1.lnk"
  call :DelFile "%%~j\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\%~1.lnk"
  call :DelFile "%%~j\AppData\Roaming\Microsoft\Windows\Start Menu\%~1.lnk"
  call :DelFile "%%~j\AppData\Roaming\Microsoft\Windows\Recent\%~1.lnk"
  call :DelFile "%%~j\Microsoft\Windows\Start Menu\Programs\Startup\%~1.lnk"
  call :DelFile "%%~j\Microsoft\Windows\Start Menu\Programs\%~1.lnk"
  call :DelFile "%%~j\Microsoft\Windows\Start Menu\%~1.lnk"
  call :DelFile "%%~j\������� ����\�ணࠬ��\��⮧���㧪�\%~1.lnk"
  call :DelFile "%%~j\������� ����\�ணࠬ��\%~1.lnk"
  call :DelFile "%%~j\������� ����\%~1.lnk"
  call :DelFile "%%~j\Desktop\%~1.lnk"
  call :DelFile "%%~j\����稩 �⮫\%~1.lnk"
)
if defined ProgramData (
  call :DelDir  "%ProgramData%\Microsoft\Windows\Start Menu\Programs\Startup\%~1"
  call :DelDir  "%ProgramData%\Microsoft\Windows\Start Menu\Programs\%~1"
  call :DelDir  "%ProgramData%\Microsoft\Windows\Start Menu\%~1"
  call :DelFile "%ProgramData%\Microsoft\Windows\Start Menu\Programs\Startup\%~1.lnk"
  call :DelFile "%ProgramData%\Microsoft\Windows\Start Menu\Programs\%~1.lnk"
  call :DelFile "%ProgramData%\Microsoft\Windows\Start Menu\%~1.lnk"
)
exit /B

:DelDirInUsers
if "%~1"=="" exit /B 1
setlocal
cd>nul 2>nul /D "%SYSTEMDRIVE%\Users" || cd>nul 2>nul /D "%SYSTEMDRIVE%\Documents and Settings" || exit /B 1
for /D %%i in ("*.*" "All Users" "Default") do ^
for /D %%j in ("%%~i\%~1") do rmdir /S /Q "%%~j"
endlocal
exit /B

:Finish
