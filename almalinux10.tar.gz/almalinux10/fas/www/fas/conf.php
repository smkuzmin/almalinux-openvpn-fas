<?php

$LANG        = 'ru';                 // 'ru', 'en'
$TIME_ZONE   = 'Europe/Samara';      // '', 'Europe/Moscow', 'Europe/Samara', 'Asia/Baku', ...
$SERVER_NAME = '';                   // '', 'fas.domain.com'
$ROOT_DIR    = 'fas';
$UPLOAD_DIR  = 'files';
$USERS_FILE  = 'users/fasuser';
$BAD_EXTS    = 'asp,aspx,bash,cgi,jsp,jspx,phar,php,php3,php4,php5,phtml,pl,ps1,py,rb,sh,shtml';

$cText       = '#FFFFFF';
$cBack       = '#000000';
$cLink       = '#88BBFF';
$cLinkA      = '#AA77EE';
$cLinkV      = '#88BBFF';
$cLinkH      = '#FFFF00';
$cServerName = '#55FFAA';
$cTitle      = '#ADFF2F';
$cDate       = '#CC99EE';
$cTime       = '#EEAAEE';
$cFail       = '#FF00FF';
$cSucc       = '#7CFC00';
$cIP         = '#DEB887';
$cUser       = '#FFE4C4';
$cPass       = '#DEB887';
$cSize       = '#00FF7F';
$cType       = '#F0E68C';
$cMD5        = '#32CD32';
$cDesc       = '#F0E68C';
$cBackTH     = '#442211';
$cTextTH     = '#FFDD00';
$cBackTD     = '#222222';

?>
