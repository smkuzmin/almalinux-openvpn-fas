const USER_SANITIZE = /[^a-z0-9._]/g;
const USER_VALIDATE = /^[a-z0-9._]{3,20}$/;

const PASS_SANITIZE = /[^a-zA-Z0-9._-]/g;
const PASS_VALIDATE = /^[a-zA-Z0-9._-]{8,20}$/;

const DESC_SANITIZE = /[^а-яёА-ЯЁa-zA-Z0-9/@#()!?;:,. _-]/g;
const DESC_VALIDATE = /^[а-яёА-ЯЁa-zA-Z0-9/@#()!?;:,. _-]{1,90}$/;

function HandlerUser (user) { user.value=user.value.toLowerCase ().replace (USER_SANITIZE, ''); }
function HandlerPass (pass) { pass.value=               pass.value.replace (PASS_SANITIZE, ''); }
function HandlerDesc (desc) { desc.value=               desc.value.replace (DESC_SANITIZE, ''); }
function HandlerBtn ()
{
  with (useradd)
  {
    btn.disabled=false;
    if (!USER_VALIDATE.test (  un.value)) btn.disabled=true;
    if (!PASS_VALIDATE.test (  pw.value)) btn.disabled=true;
    if (!DESC_VALIDATE.test (desc.value)) btn.disabled=true;
  }
}

function Rus2Trans (from)
{
  var Rus   = new Array ('а','б','в','г','д','е','ё' ,'ж' ,'з','и','й','к','л','м','н','о','п','р','с','т','у','ф','х','ц','ч' ,'ш' ,'щ'  ,'ъ','ы','ь','э','ю' ,'я' ,
                         'А','Б','В','Г','Д','Е','Ё' ,'Ж' ,'З','И','Й','К','Л','М','Н','О','П','Р','С','Т','У','Ф','Х','Ц','Ч' ,'Ш' ,'Щ'  ,'Ъ','Ы','Ь','Э','Ю' ,'Я' );
  var Trans = new Array ('a','b','v','g','d','e','yo','zh','z','i','j','k','l','m','n','o','p','r','s','t','u','f','h','c','ch','sh','sch','' ,'y','' ,'e','yu','ya',
                         'A','B','V','G','D','E','YO','ZH','Z','I','J','K','L','M','N','O','P','R','S','T','U','F','H','C','CH','SH','SCH','' ,'Y','' ,'E','YU','YA');
  var to = '';
  var i,c,isRus;
  for (i = 0; i < from.length; i++)
  {
    c = from.charAt (i,1);
    isRus = false;
    for (j = 0; j < Rus.length; j++)
      if (c == Rus[j])
      {
        isRus = true;
        break;
      }
    to += (isRus)? Trans[j] : c;
  }
  return to;
}
