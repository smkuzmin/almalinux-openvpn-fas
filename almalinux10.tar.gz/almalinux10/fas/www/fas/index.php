<?php

$username = substr ($_POST['username'] ?? '', 0, 20);
$password = substr ($_POST['password'] ?? '', 0, 20);

if ($username >= '!' && $password >= '!')
{
  setcookie ('username', $username);
  setcookie ('password', $password);
  header ('Location:home.php');
}

unset ($_COOKIE['username']);
unset ($_COOKIE['password']);

require ('head.php');

echo '
<SCRIPT language=JavaScript src=func.js></SCRIPT>
<FORM name=login method=post>
  <TABLE>
    <TR><TD><FONT color=' . $cUser. '>' . $msgUser . '</FONT><TD><INPUT type=text     name=username size=35 maxlength=20 onKeyUp=HandlerUser(this)></TR>
    <TR><TD><FONT color=' . $cPass. '>' . $msgPass . '</FONT><TD><INPUT type=password name=password size=35 maxlength=20 onKeyUp=HandlerPass(this)></TR>
  </TABLE>
  <P>
  <INPUT type=submit value="' . $msgEnter . '">
</FORM>
<P>
';

?>
