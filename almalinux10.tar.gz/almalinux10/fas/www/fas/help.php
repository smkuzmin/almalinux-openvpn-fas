<?php

require ('head.php');

if ($username < '!' || $password < '!') { echo '<FONT color=' . $cFail . ' size=+1>' . $msgPageForLoggedUser . '!</FONT> <A href=logout.php>' . $msgLogin . '</A>'; exit; }

echo $msgHelpContent;

?>
