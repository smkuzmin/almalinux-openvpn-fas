<?php

require ('head.php');

if ($username < '!' || $password < '!') { echo '<FONT color=' . $cFail . ' size=+1>' . $msgPageForLoggedUser . '!</FONT> <A href=logout.php>' . $msgLogin . '</A>'; exit; }

$tmp_name     = $_FILES['uploadfile']['tmp_name'] ?? '';
$name         = $_FILES['uploadfile']['name'    ] ?? '';
$type         = $_FILES['uploadfile']['type'    ] ?? '';
$size         = $_FILES['uploadfile']['size'    ] ?? 0;
$name         = mb_substr ($name, 0, 255, 'UTF-8');
$name         = Rus2Trans ($name);
$name         = Space2Underline ($name);
$name         = preg_replace ('/[^A-Za-z0-9.,_-]/', '', $name);
$ext          = pathinfo ($name, PATHINFO_EXTENSION);
$ext          = strtolower ($ext);
$ext          = preg_replace ('/[^a-z0-9]/', '', $ext);
$bad_exts_arr = preg_split ('/[ ,]+/', strtolower ($BAD_EXTS), -1, PREG_SPLIT_NO_EMPTY);

if (!NameIsCorrect ($name)        ) { echo '<FONT color=' . $cFail . ' size=+1>' . $msgBadFileName . '!</FONT>'; exit; }
if (in_array ($ext, $bad_exts_arr)) { echo '<FONT color=' . $cFail . ' size=+1>' . $msgBadFileExt  . '!</FONT>'; exit; }

$md5 = md5_file ($tmp_name);

echo '<P>'; if (copy ($tmp_name, $UPLOAD_DIR . '/' . $username . '-' . $md5 . '-' . $name))
echo '<FONT color=' . $cSucc . ' size=+1>' . $msgUploadSuccessful . '</FONT>'; else
echo '<FONT color=' . $cFail . ' size=+1>' . $msgUploadFailure    . '</FONT>';
echo '<P>';

//$url = HostPrefix () . HostName ($SERVER_NAME) . '/' . $ROOT_DIR . '/' . $UPLOAD_DIR . '/' . $username . '-' . $md5 . '-' . $name;
$url   = HostPrefix () . HostName ($SERVER_NAME) . '/' . $ROOT_DIR . '/download.php?file='   . $username . '-' . $md5 . '-' . $name;
$size  = HumanSize ($size);
$time  = gmdate ('i:s', time () - $_SERVER['REQUEST_TIME']);

echo '<TABLE border=1 cellPadding=3 cellSpacing=3>';
echo   '<TR><TH bgcolor=' . $cBackTH . '><FONT color=' . $cTextTH . '>&nbsp;' . $msgLink       . '&nbsp;</FONT><TD bgcolor=' . $cBackTD . '><A href="'    . $url    . '">&nbsp;' . $url  . '&nbsp;</A></TR>';
echo   '<TR><TH bgcolor=' . $cBackTH . '><FONT color=' . $cTextTH . '>&nbsp;' . $msgFile       . '&nbsp;</FONT><TD bgcolor=' . $cBackTD . '><FONT color=' . $cLinkA .  '>&nbsp;' . $name . '&nbsp;</FONT></TR>';
echo   '<TR><TH bgcolor=' . $cBackTH . '><FONT color=' . $cTextTH . '>&nbsp;' . $msgType       . '&nbsp;</FONT><TD bgcolor=' . $cBackTD . '><FONT color=' . $cType  .  '>&nbsp;' . $type . '&nbsp;</FONT></TR>';
echo   '<TR><TH bgcolor=' . $cBackTH . '><FONT color=' . $cTextTH . '>&nbsp;' . $msgSize       . '&nbsp;</FONT><TD bgcolor=' . $cBackTD . '><FONT color=' . $cSize  .  '>&nbsp;' . $size . '&nbsp;</FONT></TR>';
echo   '<TR><TH bgcolor=' . $cBackTH . '><FONT color=' . $cTextTH . '>&nbsp;' . $msgMD5        . '&nbsp;</FONT><TD bgcolor=' . $cBackTD . '><FONT color=' . $cMD5   .  '>&nbsp;' . $md5  . '&nbsp;</FONT></TR>';
echo   '<TR><TH bgcolor=' . $cBackTH . '><FONT color=' . $cTextTH . '>&nbsp;' . $msgUploadTime . '&nbsp;</FONT><TD bgcolor=' . $cBackTD . '><FONT color=' . $cTime  .  '>&nbsp;' . $time . '&nbsp;</FONT></TR>';
echo '</TABLE>';

?>
