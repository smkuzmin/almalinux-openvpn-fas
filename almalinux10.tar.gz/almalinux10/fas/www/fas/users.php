<?php

require ('head.php');

if ($username < '!' || $password < '!') { echo '<FONT color=' . $cFail . ' size=+1>' . $msgPageForLoggedUser . '!</FONT> <A href=logout.php>' . $msgLogin . '</A>'; exit; }
if ($username !== 'admin'             ) { echo '<FONT color=' . $cFail . ' size=+1>' . $msgPageForAdmin      . '!</FONT>'; exit; }

echo '
<SCRIPT language=JavaScript src=func.js></SCRIPT>
<FORM name=useradd method=post>
  <TABLE border=0>
    <TR><TD><FONT color=' . $cUser . '>' . $msgUser . '</FONT><TD><INPUT type=text name=un   size=100 maxlength=20 onKeyUp=HandlerUser(this);HandlerBtn() title="' . $msgIncorrectUser . '">
    <TR><TD><FONT color=' . $cPass . '>' . $msgPass . '</FONT><TD><INPUT type=text name=pw   size=100 maxlength=20 onKeyUp=HandlerPass(this);HandlerBtn() title="' . $msgIncorrectPass . '">
    <TR><TD><FONT color=' . $cDesc . '>' . $msgDesc . '</FONT><TD><INPUT type=text name=desc size=100 maxlength=90 onKeyUp=HandlerDesc(this);HandlerBtn() title="' . $msgIncorrectDesc . '">
  </TABLE>
  <BR>
  <INPUT type=submit name=btn value="' . $msgUserAdd . '" disabled>
</FORM>
';

$deleteuser =    substr (trim ($_POST['deleteuser'] ?? ''), 0, 20         );
$un         =    substr (trim ($_POST['un'        ] ?? ''), 0, 20         );
$pw         =    substr (trim ($_POST['pw'        ] ?? ''), 0, 20         );
$desc       = mb_substr (trim ($_POST['desc'      ] ?? ''), 0, 90, 'UTF-8');

if (UserIsCorrect ($deleteuser)) UserDel ($USERS_FILE, $deleteuser);

if($un >= '!')
{
  if ($pw < '!' || $desc < '!'                  ) { echo '<FONT color=' . $cFail . ' size=+1>' . $msgRequireAllFields . '!</FONT>'; exit; }
  if (!UserIsCorrect ($un  )                    ) { echo '<FONT color=' . $cFail . ' size=+1>' . $msgIncorrectUser    . '!</FONT>'; exit; }
  if (!PassIsCorrect ($pw  )                    ) { echo '<FONT color=' . $cFail . ' size=+1>' . $msgIncorrectPass    . '!</FONT>'; exit; }
  if (!DescIsCorrect ($desc)                    ) { echo '<FONT color=' . $cFail . ' size=+1>' . $msgIncorrectDesc    . '!</FONT>'; exit; }
  switch (AuthRes ($USERS_FILE, $un, $pw))
  {
    case 0:                                       { echo '<FONT color=' . $cFail . ' size=+1>' . $msgUserAlreadyExist . '!</FONT>'; exit; }
    case 1:                                       { echo '<FONT color=' . $cFail . ' size=+1>' . $msgUserAlreadyExist . '!</FONT>'; exit; }
    case 3:                                       { echo '<FONT color=' . $cFail . ' size=+1>' . $msgErrAccUserDB     . '!</FONT>'; exit; }
  }
  if (UserAdd ($USERS_FILE, $un, $pw, $desc) > 0) { echo '<FONT color=' . $cFail . ' size=+1>' . $msgErrAccUserDB     . '!</FONT>'; exit; }
}

UsersRead ($UPLOAD_DIR, $USERS_FILE, $USERS);
if (count ($USERS) > 0)
{
  echo '<BR>';
  echo '<TABLE border=2 cellpadding=3 cellSpacing=0>';
  echo '<TR bgcolor=' . $cBackTH . '>';
  echo   '<TH><FONT color=' . $cTextTH . '>&nbsp;' . $msgDate . '&nbsp;</FONT>';
  echo   '<TH><FONT color=' . $cTextTH . '>&nbsp;' . $msgTime . '&nbsp;</FONT>';
  echo   '<TH><FONT color=' . $cTextTH . '>&nbsp;' . $msgSize . '&nbsp;</FONT>';
  echo   '<TH><FONT color=' . $cTextTH . '>&nbsp;' . $msgUser . '&nbsp;</FONT>';
  echo   '<TH><FONT color=' . $cTextTH . '>&nbsp;' . $msgDesc . '&nbsp;</FONT>';
  echo   '<TH><FONT color=' . $cTextTH . '>&nbsp;' .            '&nbsp;</FONT>';
  echo '</TR>';
  $url = HostPrefix () . HostName ($SERVER_NAME) . '/' . $ROOT_DIR . '/home.php?user=';
  foreach ($USERS as $user => $users)
  {
    $date  =                    $users['date' ];
    $size  =         HumanSize ($users['size' ]);
    $desc  =                    $users['desc' ];
    $count = $msgFiles . ': ' . $users['count'];
    $pass  = $msgPass  . ': ' . $users['pass' ];
    [$date, $time] = explode (' ', $date, 2);
    echo '<FORM method=post enctype=multipart/form-data>';
    echo   '<TR bgcolor=' . $cBackTD . '>';
    echo     '<TD>'                                                          . '<FONT color=' . $cDate . '>&nbsp;' . $date          . '&nbsp;</FONT>';
    echo     '<TD>'                                                          . '<FONT color=' . $cTime . '>&nbsp;' . $time          . '&nbsp;</FONT>';
    echo     '<TD title="' . $count . '"><DIV align=right>'                  . '<FONT color=' . $cSize . '>&nbsp;' . $size          . '&nbsp;</FONT></DIV>';
    echo     '<TD title="' . $pass  . '"><A href="' . $url . $user . '">'    . '<FONT color=' . $cUser . '>&nbsp;' . $user          . '&nbsp;</FONT></A>';
    echo     '<TD>'                                                          . '<FONT color=' . $cDesc . '>&nbsp;' . $desc          . '&nbsp;</FONT>';
    echo     '<TD><INPUT type=hidden name=deleteuser value="' . $user . '">' .  '<INPUT type=submit value="&nbsp;' . $msgUserDelete . '&nbsp;">';
    echo   '</TR>';
    echo '</FORM>';
  }
  echo '</TABLE>';
}

?>
