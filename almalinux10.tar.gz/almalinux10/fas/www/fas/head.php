<?php

$LANG        = 'ru';
$TIME_ZONE   = 'Europe/Moscow';
$SERVER_NAME = '';
$ROOT_DIR    = 'fas';
$UPLOAD_DIR  = 'files';
$USERS_FILE  = 'users/fasuser';
$BAD_EXTS    = 'asp,aspx,bash,cgi,jsp,jspx,phar,php,php3,php4,php5,phtml,pl,ps1,py,rb,sh,shtml';

$cText       = '#FFFFFF';
$cBack       = '#000000';
$cLink       = '#88BBFF';
$cLinkA      = '#AA77EE';
$cLinkV      = '#88BBFF';
$cLinkH      = '#FFFF00';
$cServerName = '#55FFAA';
$cTitle      = '#ADFF2F';
$cDate       = '#CC99EE';
$cTime       = '#EEAAEE';
$cFail       = '#FF00FF';
$cSucc       = '#7CFC00';
$cIP         = '#DEB887';
$cUser       = '#FFE4C4';
$cPass       = '#DEB887';
$cSize       = '#00FF7F';
$cType       = '#F0E68C';
$cMD5        = '#32CD32';
$cDesc       = '#F0E68C';
$cBackTH     = '#442211';
$cTextTH     = '#FFDD00';
$cBackTD     = '#222222';

include_once ('conf.php');
include_once ('func.php');
include_once ('lang.' . ($LANG === 'ru'? 'ru' : 'en') . '.php');

if ($TIME_ZONE > '!') date_default_timezone_set ($TIME_ZONE);

echo '
<HEAD>
  <TITLE>' . $msgTitle . '</TITLE>
   <STYLE>
     body     {color: ' . $cText  . '; background: ' . $cBack . '}
     a        {text-decoration: none}
     a:link   {color: ' . $cLink  . '}
     a:active {color: ' . $cLinkA . '}
     a:visited{color: ' . $cLinkV . '}
     a:hover  {color: ' . $cLinkH . '}
     td,th    {text-align: left}
  </STYLE>
</HEAD>
<TABLE width=100%>
  <TR>
    <TD valign=bottom><DIV align=left  ><FONT color=' . $cServerName . ' size=+2><B>' . HostName ($SERVER_NAME)  . '</B></FONT></DIV>
    <TD valign=bottom><DIV align=center><FONT color=' . $cTitle      . ' size=+2><B>' . $msgTitle                . '</B></FONT></DIV>
    <TD valign=bottom><DIV align=right ><FONT color=' . $cDate       . ' size=+1><B>' . date ('d M Y. l, H:i:s') . '</B></FONT></DIV>
  </TR>
</TABLE>
<HR>
';

$username = substr ($_COOKIE['username'] ?? '', 0, 20);
$password = substr ($_COOKIE['password'] ?? '', 0, 20);

if ($username >= '!' && $password >= '!')
{
  $userip    = $_SERVER['REMOTE_ADDR'    ] ?? 'unknown';
  $useragent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';

  if (!UserIsCorrect ($username) || !PassIsCorrect ($password))
  {
    error_log ("FAS_AUTH_FAIL: IP=$userip USER=\"$username\" AGENT=\"$useragent\" REASON=\"Incorrect user or password\"");
    sleep (2);
    echo '<FONT color=' . $cFail . ' size=+1>' . $msgInvalidCred . '.</FONT> <A href=logout.php>' . $msgLogin . '</A>';
    exit;
  }

  $authres = AuthRes ($USERS_FILE, $username, $password);

  if ($authres > 0)
  {
    switch ($authres)
    {
      case 1: $reason = "Invalid password"       ; $errmsg = $msgInvalidCred ; break;
      case 2: $reason = "Invalid user"           ; $errmsg = $msgInvalidCred ; break;
      case 3: $reason = "User database not found"; $errmsg = $msgErrAccUserDB; break;
    }
    error_log ("FAS_AUTH_FAIL: IP=$userip USER=\"$username\" AGENT=\"$useragent\" REASON=\"$reason\"");
    sleep (2);
    echo '<FONT color=' . $cFail . ' size=+1>' . $errmsg . '.</FONT> <A href=logout.php>' . $msgLogin . '</A>';
    exit;
  }

  error_log ("FAS_AUTH_SUCC: IP=$userip USER=\"$username\" AGENT=\"$useragent\"");

  echo   ' [ <FONT color=' . $cUser . '>'     . $msgUser . ': ' . $username              . '</FONT> ]';
  echo   ' [ <FONT color=' . $cIP   . '>IP: ' . $_SERVER['REMOTE_ADDR']                  . '</FONT> ]';
  if ($username == 'admin')
  {
    $upload_dir_free_space = HumanSize (disk_free_space (getcwd () . '/' . $UPLOAD_DIR));
    echo ' [ <FONT color=' . $cSize . '>'     . $msgFree . ': ' . $upload_dir_free_space . '</FONT> ]';
    echo ' [ <A href=home.php>'               . $msgHome                                 . '</A> ]';
    echo ' [ <A href=users.php>'              . $msgUsers                                . '</A> ]';
  }
  else
  {
    echo ' [ <A href=home.php>'               . $msgHome                                 . '</A> ]';
  }
  echo   ' [ <A href=help.php>'               . $msgHelp                                 . '</A> ]';
  echo   ' [ <A href=logout.php>'             . $msgLogout                               . '</A> ]';
  echo   '<HR>';
}
echo '<BR>';

?>
