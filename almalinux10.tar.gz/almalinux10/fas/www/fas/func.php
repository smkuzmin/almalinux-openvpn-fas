<?php

// Проверяем корректность имени пользователя
function UserIsCorrect ($user)
{
  return preg_match ('/^[a-zA-Z0-9._]{3,20}$/', $user);
}

// Проверяем корректность пароля пользователя
function PassIsCorrect ($pass)
{
  return preg_match ('/^[a-zA-Z0-9._-]{8,20}$/', $pass);
}

// Проверяем корректность описания пользователя
function DescIsCorrect ($desc)
{
  if ($desc < '!') return false;
  return preg_match ('/^[а-яёА-ЯЁa-zA-Z0-9\/@#()!?;:,. _-]{1,90}$/u', $desc);
}

// Проверяем корректность MD5
function MD5IsCorrect ($md5)
{
  return preg_match ('/^[0-9a-f]{32}$/', $md5);
}

// Проверяем корректность имени файла
function NameIsCorrect ($name)
{
  return preg_match ('/^[a-zA-Z0-9.,_-]{1,255}$/', $name);
}

// Возвращаем префикс.
function HostPrefix ()
{
  if (isset ($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') return 'https://';
  return 'http://';
}

// Возвращаем имя сервера.
function HostName ($hostname)
{
                                       if ($hostname > '!') return ($hostname);  // Возвращаем заданное имя.
  $hostname = $_SERVER['SERVER_NAME']; if ($hostname > '!') return ($hostname);  // Возвращаем имя / IP хоста, по которому обратились.
//$hostname = $_SERVER['SERVER_ADDR']; if ($hostname > '!') return ($hostname);  // Возвращаем первый попавшийся IP-адрес.
//$hostname = php_uname ('n');         if ($hostname > '!') return ($hostname);  // Возвращаем системное имя.
                                                            return 'localhost';  // Возвращаем localhost.
}

// Возвращаем максимальный размер загружаемого файла.
function MaxUploadSize ()
{
  $file_uploads         =                  SafeIniGet ('file_uploads'       , '0'  );  if ($file_uploads        !== '1') return 0;
  $upload_tmp_dir_size  = disk_free_space (SafeIniGet ('upload_tmp_dir'     , '.'  )); if ($upload_tmp_dir_size === '' ) return 0;
  $post_max_size        =     DeHumanSize (SafeIniGet ('post_max_size'      , '0'  ));
  $upload_max_file_size =     DeHumanSize (SafeIniGet ('upload_max_filesize', '0'  ));
  $max_size             = min ($post_max_size, $upload_max_file_size);
  $max_size             = min ($max_size     , $upload_tmp_dir_size );
  return $max_size;
}

// Возвращаем дату и время в удобном виде.
function DateTime ($timestamp)
{
  if ($timestamp === '') return date ('Y.m.d H:i:s');
  else                   return date ('Y.m.d H:i:s', $timestamp);
}

// Возвращаем время в удобном для чтения виде.
function HumanTime ($time)
{
  if ($time < 60      ) return        $time              . ' sec'   ; // < 1 min
  if ($time < 3600    ) return round ($time/60      , 1) . ' min'   ; // < 1 hour
  if ($time < 86400   ) return round ($time/3600    , 1) . ' hours' ; // < 1 day
  if ($time < 2592000 ) return round ($time/86400   , 1) . ' days'  ; // < 1 month
  if ($time < 31104000) return round ($time/259200  , 1) . ' months'; // < 1 year
  else                  return round ($time/31104000, 1) . ' years' ;
}

// Возвращаем размер в удобном виде (1363149 => 1,3M).
function HumanSize ($size)
{
  if ($size < 1024            ) return        $size;
  if ($size < 1048576         ) return round ($size/1024         , 1) . 'K';
  if ($size < 1073741824      ) return round ($size/1048576      , 1) . 'M';
  if ($size < 1099511627776   ) return round ($size/1073741824   , 1) . 'G';
  if ($size < 1125899906842624) return round ($size/1099511627776, 1) . 'T';
}

// Возвращаем размер в неудобном виде (1,3M => 1363149).
function DeHumanSize ($size)
{
  $size = preg_replace ('/,/', '.'             , $size);
  $size = preg_replace ('/K/', '*1024'         , $size);
  $size = preg_replace ('/M/', '*1048576'      , $size);
  $size = preg_replace ('/G/', '*1073741824'   , $size);
  $size = preg_replace ('/T/', '*1099511627776', $size);
  eval ("\$size = $size;");
  return round ($size);
}

// Заменяем в строке пробелы на подчеркивания.
function Space2Underline ($str)
{
  return strtr ($str, ' ', '_');
}

// Переводим строку в транслит.
function Rus2Trans ($str)
{
  $replacements = [
    'а' => 'a' , 'б' => 'b' , 'в' => 'v'  , 'г' => 'g', 'д' => 'd', 'е' => 'e', 'ё' => 'e', 'ж' => 'zh',
    'з' => 'z' , 'и' => 'i' , 'й' => 'i'  , 'к' => 'k', 'л' => 'l', 'м' => 'm', 'н' => 'n', 'о' => 'o' ,
    'п' => 'p' , 'р' => 'r' , 'с' => 's'  , 'т' => 't', 'у' => 'u', 'ф' => 'f', 'х' => 'h', 'ц' => 'c' ,
    'ч' => 'ch', 'ш' => 'sh', 'щ' => 'sch', 'ы' => 'y', 'ь' => '' , 'ъ' => '' , 'э' => 'e', 'ю' => 'yu', 'я' => 'ya',
    'А' => 'A' , 'Б' => 'B' , 'В' => 'V'  , 'Г' => 'G', 'Д' => 'D', 'Е' => 'E', 'Ё' => 'E', 'Ж' => 'ZH',
    'З' => 'Z' , 'И' => 'I' , 'Й' => 'I'  , 'К' => 'K', 'Л' => 'L', 'М' => 'M', 'Н' => 'N', 'О' => 'O' ,
    'П' => 'P' , 'Р' => 'R' , 'С' => 'S'  , 'Т' => 'T', 'У' => 'U', 'Ф' => 'F', 'Х' => 'H', 'Ц' => 'C' ,
    'Ч' => 'CH', 'Ш' => 'SH', 'Щ' => 'SCH', 'Ы' => 'Y', 'Ь' => '' , 'Ъ' => '' , 'Э' => 'E', 'Ю' => 'YU', 'Я' => 'YA',
  ];
  return strtr ($str, $replacements);
}

// Возвращаем размер файлов, соответствующих маске.
function FilesSizeCount ($fnmask, &$count)
{
  $size  = 0;
  $count = 0;
  $files_arr = glob ($fnmask);
  if ($files_arr === null) return 0;
  foreach ($files_arr as $fn)
  {
    $size  = $size + filesize ($fn);
    $count = $count + 1;
  }
  return $size;
}

// Возвращаем результат аутентификации:
//   0 - пользователь существует, пароль правильный
//   1 - пользователь существует, пароль неправильный
//   2 - пользователь не существует
//   3 - файл базы пользователей не найден
function AuthRes ($fn, $user, $pass)
{
  if (!is_file ($fn)) return 3;
  $fh = fopen ($fn, 'r');
  while (!feof ($fh))
  {
    $s_arr = explode ('|', fgets ($fh), 4);
    if (count ($s_arr) < 4) continue;
    $u1 = trim ($s_arr[0]);
    $p1 = trim ($s_arr[1]);
    $u_correct = ($user === $u1);
    $p_correct = ($pass === $p1);
    if ($u_correct &&  $p_correct) return 0;
    if ($u_correct && !$p_correct) return 1;
  }
  fclose ($fh);
  return 2;
}

// Добавляем пользователя с паролем в файл.
//   0 - пользователь добавлен
//   1 - файл базы пользователей не найден
function UserAdd ($fn, $user, $pass, $desc)
{
  if (!is_file ($fn)) return 1;
  $fh = fopen ($fn, 'a');
  fwrite ($fh, $user . '|' . $pass . '|' . DateTime ('') . '|' . trim ($desc) . "\n");
  fclose ($fh);
  return 0;
}

// Удаляем пользователя из файла.
//   0 - пользователь удалён
//   1 - файл базы пользователей не найден
//   2 - нельзя удалить администратора
function UserDel ($fn, $user)
{
  if (!is_file ($fn)) return 1;
  if ($user === 'admin'  ) return 2;
  $file = file ($fn);
  $fh = fopen ($fn, 'w');
  foreach ($file as $line)
    if (strtok ($line, '|') !== $user) fwrite ($fh, $line);
  fclose ($fh);
  return 0;
}

// Возвращаем массив пользователей.
function UsersRead ($dir_name, $users_file, &$users_arr)
{
  $users_arr = [];
  if (!is_file ($users_file)) return 1;
  $fh = fopen ($users_file, 'r');
  while (!feof ($fh))
  {
    $s_arr = explode ('|', fgets ($fh), 4);
    if (count ($s_arr) !== 4) continue;
    [$user, $pass, $date, $desc] = array_map ('trim', $s_arr);
    $size = FilesSizeCount ("$dir_name/$user-*", $count);
    $users_arr[$user]['pass' ] = $pass;
    $users_arr[$user]['date' ] = $date;
    $users_arr[$user]['desc' ] = $desc;
    $users_arr[$user]['size' ] = $size;
    $users_arr[$user]['count'] = $count;
  }
  fclose ($fh);
  if ($users_arr) uasort ($users_arr, function ($a,$b) {return $b['date'] <=> $a['date'];});
}

// Возвращаем массив файлов для пользователя.
function FilesRead ($dir_name, $user, &$files_arr)
{
  $files_arr = [];
  if (!is_dir      ($dir_name)) return 1;
  if (!is_readable ($dir_name)) return 1;
  $dh = opendir ($dir_name); if (!$dh) return 1;
  while ($fn = readdir ($dh))
  {
    $fn_arr = explode ('-', $fn, 3);
    if (count ($fn_arr) === 3)
      if ($user === $fn_arr[0] || $user === 'admin')
        if (UserIsCorrect ($fn_arr[0]))
          if (MD5IsCorrect ($fn_arr[1]))
            if (NameIsCorrect ($fn_arr[2]))
              if (is_file ("$dir_name/$fn"))
                $files_arr[] = [
                  'user' => $fn_arr[0],
                  'md5'  => $fn_arr[1],
                  'name' => $fn_arr[2],
                  'date' => DateTime  (filemtime ("$dir_name/$fn")),
                  'size' => HumanSize (filesize  ("$dir_name/$fn"))
                ];
  }
  closedir ($dh);
  if ($files_arr) uasort ($files_arr, function ($a,$b) {return $b['date'] <=> $a['date'];});
}

// Получаем значения параметров из файла "php.ini" и задаём для них значения по умолчанию.
function SafeIniGet ($name, $val_on_empty)
{
  $val = trim (ini_get ($name)); if ($val === '') return $val_on_empty;
  return $val;
}

?>
