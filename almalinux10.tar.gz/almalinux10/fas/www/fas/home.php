<?php

require ('head.php');

if ($username < '!' || $password < '!') { echo '<FONT color=' . $cFail . ' size=+1>' . $msgPageForLoggedUser . '!</FONT> <A href=logout.php>' . $msgLogin . '</A>'; exit; }

$deletefile = substr ($_POST['deletefile'] ?? '', 0, 255);
$df_arr     = explode ('-', $deletefile, 3);
if (count ($df_arr) === 3)
  if (UserIsCorrect ($df_arr[0]) && MD5IsCorrect ($df_arr[1]) && NameIsCorrect ($df_arr[2]))
    if (is_file ("$UPLOAD_DIR/$deletefile"))
      unlink ("$UPLOAD_DIR/$deletefile");

if ($username !== 'admin')
{
  echo '<I><FONT color=' . $cFail . '>' . $msgMaxSizeUploadedFile . ': ' . HumanSize (MaxUploadSize ()) . '</FONT></I>';
  echo '<P>';
  echo '<FORM action=upload.php method=post enctype=multipart/form-data>';
  echo   '<INPUT type=file name=uploadfile size=100>&nbsp;&nbsp;';
  echo   '<INPUT type=submit value="' . $msgUploadFile . '">';
  echo '</FORM>';
  echo '<P>';
}

$showuser = $username;
if ($username === 'admin')
  if (isset ($_GET['user']))
    if (UserIsCorrect ($_GET['user']))
      $showuser = $_GET['user'];
FilesRead ($UPLOAD_DIR, $showuser, $FILES);
if (count ($FILES) > 0)
{
  echo '<BR>';
  echo '<TABLE border=2 cellpadding=3 cellSpacing=0>';
  echo   '<TR bgcolor=' . $cBackTH . '>';
  echo     '<TH><FONT color=' . $cTextTH . '>&nbsp;' . $msgDate . '&nbsp;</FONT>';
  echo     '<TH><FONT color=' . $cTextTH . '>&nbsp;' . $msgTime . '&nbsp;</FONT>';
  echo     '<TH><FONT color=' . $cTextTH . '>&nbsp;' . $msgSize . '&nbsp;</FONT>';
  if ($username === 'admin')
    echo   '<TH><FONT color=' . $cTextTH . '>&nbsp;' . $msgUser . '&nbsp;</FONT>';
  echo     '<TH><FONT color=' . $cTextTH . '>&nbsp;' . $msgFile . '&nbsp;</FONT>';
  echo     '<TH><FONT color=' . $cTextTH . '>&nbsp;' .            '&nbsp;</FONT>';
  echo   '</TR>';
  $root_url = HostPrefix () . HostName ($SERVER_NAME) . '/' . $ROOT_DIR;
  foreach ($FILES as $files)
  {
    $user     = $files['user'];
    $md5      = $files['md5' ];
    $name     = $files['name'];
    $date     = $files['date'];
    $size     = $files['size'];
    $fullname = $user . '-' . $md5 . '-' . $name;
//  $url_f    = $root_url . '/' . $UPLOAD_DIR . '/' . $fullname;
    $url_f    = $root_url . '/download.php?file='   . $fullname;
    $url_u    = $root_url . '/home.php?user='       . $user;
    [$date, $time] = explode (' ', $date, 2);
    echo '<FORM method=post enctype=multipart/form-data>';
    echo   '<TR bgcolor=' . $cBackTD . '>';
    echo     '<TD>' .             '<FONT color=' . $cDate . '>&nbsp;' . $date . '&nbsp;</FONT>';
    echo     '<TD>' .             '<FONT color=' . $cTime . '>&nbsp;' . $time . '&nbsp;</FONT>';
    echo     '<TD><DIV align=right><FONT color=' . $cSize . '>&nbsp;' . $size . '&nbsp;</FONT></DIV>';
    if ($username === 'admin')
    {
      if (AuthRes ($USERS_FILE, $user, '') === 2) $user = '<STRIKE>' . $user . '</STRIKE>';
      echo   '<TD><A href="' . $url_u . '"><FONT color=' . $cUser . '>&nbsp;' . $user . '&nbsp;</FONT></A>';
    }
    echo     '<TD><A title="' . $url_f . '" href="' . $url_f . '">&nbsp;' . $name . '&nbsp;</A>';
    echo     '<TD><INPUT type=hidden name=deletefile value="' . $fullname . '"><INPUT type=submit value="&nbsp;' . $msgFileDelete . '&nbsp;">';
    echo   '</TR>';
    echo '</FORM>';
  }
  echo '</TABLE>';
}

?>
