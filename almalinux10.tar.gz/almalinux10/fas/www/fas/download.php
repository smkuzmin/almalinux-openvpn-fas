<?php

include_once ('conf.php');

if (!isset ($_GET['file'])) exit;
if (empty  ($_GET['file'])) exit;

$requested_file = basename ($_GET['file']);
$returned_file  = explode ('-', $requested_file, 3)[2] ?? '';

if (empty ($returned_file)) exit;
$handle = fopen ("$UPLOAD_DIR/$requested_file", 'rb');
if ($handle === false) exit;

ob_end_clean ();
set_time_limit (0);

header ('Content-Type: application/octet-stream');
header ("Content-Disposition: attachment; filename=\"$returned_file\"");
header ('Content-Transfer-Encoding: binary');
header ('Cache-Control: must-revalidate');
header ('Pragma: public');

fpassthru ($handle);
fclose ($handle);

?>
