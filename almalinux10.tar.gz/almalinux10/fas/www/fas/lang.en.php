<?php

$msgTitle = 'File Allocation System';
$msgLogin = 'Please login';
$msgLogout = 'Logout';
$msgHome = 'Home';
$msgHelp = 'Help';
$msgBack = 'Back';
$msgInvalidCred = 'Invalid user or password';
$msgIncorrectUser = 'Username must be between 3 and 20 characters and may contain letters, numbers, hyphens and underscores';
$msgIncorrectPass = 'Password must be between 8 and 20 characters and may contain letters, numbers, hyphens, underscores and periods';
$msgIncorrectDesc = 'Description must not be empty';
$msgErrAccUserDB = 'Users database not found';
$msgUsers = 'Users';
$msgPageForLoggedUser = 'This is page for logged user only';
$msgPageForAdmin = 'This is page for administrator only';
$msgRequireAllFields = 'All fields are required';
$msgUser = 'User';
$msgUserAdd = 'Add user';
$msgUserDelete = 'Delete';
$msgPass = 'Password';
$msgPassConf = 'Confirm password';
$msgDesc = 'Description';
$msgEnter = 'Enter';
$msgPassNotMatch = 'Passwords does not match';
$msgUserAlreadyExist = 'User already exist';
$msgMaxSizeUploadedFile = 'Maximum size of uploaded file';
$msgUploadFile = 'Upload file';
$msgUploadSuccessful = 'Upload file successfully';
$msgUploadFailure = 'Unable to upload file';
$msgUploadTime = 'Upload time';
$msgBadFileName = 'Bad file name';
$msgBadFileExt = 'Bad file extension';
$msgFree = 'Free';
$msgDate = 'Date';
$msgTime = 'Time';
$msgSize = 'Size';
$msgType = 'Type';
$msgMD5 = 'MD5 hash';
$msgLink = 'Link';
$msgFile = 'File';
$msgFiles = 'Files';
$msgFileDelete = 'Delete';
$msgHelpContent = '
<FONT color=' . $cDesc . '>
<P><B>About the system:</B>
<UL>
<LI>The File Allocation System (FAS) is designed to exchange files.
<LI>You can upload your files to the system and receive direct Internet links to them.
<LI>Links have no time or download limit.
<LI>Maximum upload file size (bytes): ' . HumanSize (MaxUploadSize ()) . '
</UL>
<P><B>How to upload a file:</B>
<UL>
<LI>Go to the "' . $msgHome . '" section;
<LI>Click the "Browse" button and select the file to upload;
<LI>Click the "Upload file" button;
<LI>If the upload is successful, you can immediately copy the link provided - right-click and select "Copy link address" / "Copy link".
</UL>
<P><B>How to get a link to an already uploaded file:</B>
<UL>
<LI>Go to the "' . $msgHome . '" section;
<LI>Hover your mouse over the desired file in the "' . $msgFile . '" column;
<LI>Right-click and select "Copy link address" / "Copy link".
</UL>
<P><B>Recommendations:</B>
<UL>
<LI>It is recommended to archive files before uploading them.
<LI>It usually does not make sense to archive single large files due to their poor compression (audio, video, archives, etc.).
<LI>Advantages of file archiving:
<UL>
<LI>multiple files are transferred via one link;
<LI>they can be password protected;
<LI>their integrity (invariance) is guaranteed during uploading and downloading;
<LI>their transmission time is reduced;
<LI>the space they occupy is reduced.
</UL>
</UL>
</FONT>
';

?>
