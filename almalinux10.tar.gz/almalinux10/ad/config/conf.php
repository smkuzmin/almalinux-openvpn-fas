<?php

  $LDAP_SERVER = "domain.local";
  $LDAP_USER   = "adinfo@domain.local";
  $LDAP_PASS   = "adinfo_pass";
  $BASE_DN     = "OU=Organizations,DC=domain,DC=local";
# $BASE_DN     = "OU=ORGNAME,OU=Organizations,DC=domain,DC=local";
  $ATTRIBUTES  = array (
                        "samaccountname",
#                       "company",
                        "mail",
                        "name",
                        "telephonenumber",
                        "title",
                        "department"
                       );

?>
