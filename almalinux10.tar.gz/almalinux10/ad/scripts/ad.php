#!/usr/bin/php
<?php

  error_reporting (0);
# error_reporting (E_ALL & ~E_DEPRECATED);

  $CONF_FILE = "/etc/ad/conf.php";

  if (!file_exists ($CONF_FILE))
  {
    fwrite (STDERR, "ERROR: File \"$CONF_FILE\" does not exist\n\n");
    exit (1);
  }

  try
  {
    include_once ($CONF_FILE);
  }
  catch (Throwable $e)
  {
    fwrite (STDERR, "ERROR: Failed to include config file: " . $e -> getMessage () . "\n");
    exit (1);
  }

  $required_vars = ['LDAP_SERVER', 'LDAP_USER', 'LDAP_PASS', 'BASE_DN', 'ATTRIBUTES'];
  foreach ($required_vars as $var)
  {
    if (!isset ($$var) || empty ($$var))
    {
      fwrite (STDERR, "ERROR: Could not find variable \"\$$var\"\n\n");
      exit (1);
    }
  }

  // Получение атрибутов пользователей из LDAP с поддержкой постраничного поиска
  function get_users_attrs_from_ldap ($dc_descr, $base_dn, $attrs_list, &$result)
  {
    $start_chars = "0123456789abcdefghijklmnopqrstuvwxyz._-";
    $item = 0;

    // Определяем размер страницы (меньше лимита сервера)
    $page_size = 500;

    foreach (str_split ($start_chars) as $char)
    {
      $filter = "(&(samaccountname=" . $char . "*)(objectcategory=user))";
      $cookie = null;
      do
      {
        // Настройка постраничного поиска
        $controls =
        [
          [
            "oid"        => LDAP_CONTROL_PAGEDRESULTS,
            "iscritical" => true,
            "value"      => [
                              "size"   => $page_size,
                              "cookie" => $cookie
                            ]
          ]
        ];

        // Выполнение поиска с контролем
        $result_id = ldap_search ($dc_descr, $base_dn, $filter, $attrs_list, 0, $page_size, -1, LDAP_DEREF_NEVER, $controls);

        if ($result_id === false) continue;

        // Получение результатов
        $entries = ldap_get_entries ($dc_descr, $result_id);
        if ($entries === false) continue;

        // Обработка полученных записей
        $entries_count = $entries ['count'];
        for ($e = 0; $e < $entries_count; $e++)
        {
          $result [$item] = [];
          for ($a = 0; $a < count ($attrs_list); $a++)
          {
            $attr_name = $attrs_list[$a];
            $attr_value = "";

            if (isset ($entries [$e] [$attr_name] [0]))
            {
              $attr_value = $entries [$e] [$attr_name] [0];
              // Приводим значение к UTF-8
              if (!empty ($attr_value) && !mb_check_encoding ($attr_value, 'UTF-8'))
                $attr_value = @iconv ('Windows-1251', 'UTF-8//IGNORE', $attr_value) ?: $attr_value;
            }
            $result [$item] [$a] = $attr_value;
          }
          $item++;
        }

        // Получение cookie для следующей страницы
        ldap_parse_result ($dc_descr, $result_id, $errcode, $matcheddn, $errmsg, $referrals, $serverctrls);
        if (isset ($serverctrls [LDAP_CONTROL_PAGEDRESULTS] ['value'] ['cookie']))
          $cookie = $serverctrls [LDAP_CONTROL_PAGEDRESULTS] ['value'] ['cookie'];
        else
          $cookie = null;

        // Если cookie пустой, значит больше нет данных
        if (empty ($cookie)) break;
      } while (true);
    }
  }

  // Отображение атрибутов пользователей
  function show_users_attrs ($users_attrs)
  {
    foreach ($users_attrs as $user_attrs)
    {
      foreach ($user_attrs as $user_attr)
      {
        // Приведение к UTF-8 и очистка от проблемных символов
        if (is_string ($user_attr))
        {
          $user_attr = preg_replace ('/[\x00-\x1F\x7F]/', '', $user_attr);
          if (!mb_check_encoding ($user_attr, 'UTF-8'))
            $user_attr = @iconv ('Windows-1251', 'UTF-8//IGNORE', $user_attr) ?: $user_attr;
          // Замена символов, которые могут сломать вывод
          $user_attr = str_replace (["\xE2\x80\x94", "\xE2\x80\x93"], "-", $user_attr);
        }
        echo " :" . $user_attr;
      }
      echo "\n";
    }
  }

  try
  {
    // Устанавливаем локаль для UTF-8
    setlocale (LC_ALL, 'ru_RU.UTF-8', 'ru_RU', 'Russian_Russia.1251');
    mb_internal_encoding ('UTF-8');

    // Подключение к LDAP
    $dc_descr = ldap_connect ($LDAP_SERVER);
    if (!$dc_descr) throw new Exception ("Could not connect to \"$LDAP_SERVER\"");

    // Настройка параметров LDAP
    ldap_set_option ($dc_descr, LDAP_OPT_PROTOCOL_VERSION, 3 );
    ldap_set_option ($dc_descr, LDAP_OPT_REFERRALS       , 0 );
    ldap_set_option ($dc_descr, LDAP_OPT_NETWORK_TIMEOUT , 10);

    // Привязка к серверу
    $dc_bind = ldap_bind ($dc_descr, $LDAP_USER, $LDAP_PASS);
    if (!$dc_bind)
    {
      $error = ldap_error ($dc_descr);
      throw new Exception ("Could not bind to \"$LDAP_SERVER\": $error");
    }

    echo "# Connected to LDAP server successfully\n";

    // Получение данных
    $ad_users_attrs = [];
    get_users_attrs_from_ldap ($dc_descr, $BASE_DN, $ATTRIBUTES, $ad_users_attrs);

    echo "# Retrieved " . count ($ad_users_attrs) . " records\n";

    asort ($ad_users_attrs);

    // Вывод результатов
    show_users_attrs ($ad_users_attrs);
  }
  catch (Throwable $e)
  {
    fwrite (STDERR, "ERROR: " . $e -> getMessage () . "\n\n");
    exit (1);
  }
  finally
  {
    // Закрытие соединения
    if (isset ($dc_descr) && is_resource ($dc_descr)) @ldap_unbind ($dc_descr);
  }

  exit (0);
?>
